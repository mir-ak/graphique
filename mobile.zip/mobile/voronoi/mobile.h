/*!\file mobile.h 
 *
 *\brief Mobiles dessinés à l'aide de disques.
 *
 * \author Farès BELHADJ, amsi@up8.edu
 * \date June 03 2020
 */

#ifndef MOBILE_H_INCLUDED
#  define MOBILE_H_INCLUDED

#include <GL4D/gl4dummies.h>

#  ifdef __cpluplus
extern "C" {
#  endif

  extern void vdInit(int nb_sites);
  extern void vdFree(void);
  extern void Move_voronoi(void);
  extern void vd2Data(void);

#  ifdef __cpluplus
}
#  endif

#endif
