/*!\file basic.fs
 *
 * \brief .
 * \author Farès BELHADJ, amsi@up8.edu
 * \date June 5, 2020
 */
/* Version GLSL 3.30 */
#version 330
uniform sampler1D tex;
uniform int nbmob;

in vec2 vsoTexCoord;

/* sortie du frament shader : une couleur */
out vec4 fragColor;

vec4 mobile(void) {
  float pas = 1.0 / (2.0 * float(nbmob));
  float i;
  vec4 texel0, texel1;
  for(i = pas / 2.0; i <= 1.0; i += 2.0 * pas) {
    texel0 = texture(tex, i);
    texel1 = texture(tex, i + pas);
    if(length(texel0.xy - vsoTexCoord.xy) < 0.01)
      return vec4(texel1);
  }
  return vec4(0);
}

vec4 voronoi(void) {
  float pas = 1.0 / (2.0 * float(nbmob));
  float i, distanceEntreMoiEtLeMobileI;
  vec4 texel0, texel1, uneCouleur;
  for(i = pas / 2.0; i <= 1.0; i += 2.0 * pas) {
    texel0 = texture(tex, i);
    texel1 = texture(tex, i + pas);
    distanceEntreMoiEtLeMobileI = length(texel0.xy - vsoTexCoord.xy);
    /* il faut trouver le moyen de calculer la bonne couleur */
  }
  return vec4(uneCouleur);
}

void main(void) {
  fragColor = voronoi();
}
