/*!\file mobile.c
 *
 *\brief Simulation basique de déplacement de mobiles dessinés à
 *l'aide d'un disque.
 *
 * \author Farès BELHADJ, amsi@up8.edu
 * \date June 03 2020
 */

#include "mobile.h"
#include <stdlib.h>
#include <assert.h>
#include <GL4D/gl4dp.h>

/* \brief type de donnée pour un mobile */
/* \brief type de donnée pour une cellule */
typedef struct vd_site_t vd_site_t;

/* \brief structure de données de la cellule : coordonnée 2d, couleur
 * et état. */
struct vd_site_t {
  GLfloat x, y;
  GLfloat r, g, b;
  GLfloat vx, vy;
};


/* \brief le diagramme de voronoi */
static vd_site_t * _sites = NULL;
/* \brief le nombre de sites du diagramme de voronoi */
static int _nb_sites = 0;
/* \brief le rayon en cours pour tous les sites */
static int _radius = 3;
/* \brief la couleur pour les positions non occupées */
static const GLuint _libre = 0x0;

/* \brief récupère pour le mobile \a mobileIndex la couleur présente
 *  dans l'image \ref _background */
/* identifiant de texture OpenGL */
static GLuint _texId = 0;

/* \brief initialise (ou réinitialise) l'ensemble des mobiles de la
 * simulation, leur nombre est donné par \a nb_mobiles.
 *
 * \param nb_mobiles le nombre de mobiles de la simulation.
 */
void vdInit(int nb_sites) {
  int i, w = gl4dpGetWidth(), h = gl4dpGetHeight();
  GLuint * screen = gl4dpGetPixels();

  if(_sites) {
    vdFree();
  } else {
    atexit(vdFree);
  }
  _nb_sites = nb_sites;
  _sites = malloc(_nb_sites * sizeof *_sites);
  assert(_sites);
  for(i = 0; i < _nb_sites; ++i) {
  
    _sites[i].x = (GLfloat)(gl4dmURand() * w);
    _sites[i].y = (GLfloat)(gl4dmURand() * h);
    _sites[i].r = (GLfloat)gl4dmURand();
    _sites[i].g = (GLfloat)gl4dmURand();
    _sites[i].b = (GLfloat)gl4dmURand();
    _sites[i].vx = (float)(gl4dmSURand() * 20.0);
    _sites[i].vy = (float)(gl4dmSURand() * 20.0);
  }
  glGenTextures(1, &_texId);
  glBindTexture(GL_TEXTURE_1D, _texId);
  glTexParameterf(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameterf(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glBindTexture(GL_TEXTURE_1D, 0);
}


/* \brief libère la mémoire et réinitialise les paramètres de la
 *  simulation. Cette fonction est potentiellement appelée à
 *  l'événement exit.
 */
void vdFree(void) {
  if(_sites) {
    free(_sites);
    _sites = NULL;
    _nb_sites = 0;
  }
}



/* \brief déplace tous les mobiles en fonction de leur position,
 * vitesse et du temps.
 */
void Move_voronoi(void) {
  gl4dpScreenHasChanged();
  
  int i, w = gl4dpGetWidth(), h = gl4dpGetHeight();
  /* récupération du dt */
  static double t0 = 0.1;
  double t = gl4dGetElapsedTime() / 1000.0;
  double dt = t - t0;
  t0 = t;
  /* fin de récupération du dt */
  for(i = 0; i < _nb_sites ; ++i) {
    /* futur x et futur y */
    float fx, fy;
    fx = _sites[i].x + _sites[i].vx * dt;
    fy = _sites[i].y + _sites[i].vy * dt;
    if((fx < _radius && _sites[i].vx < 0.0f) ||
       (fx > w - _radius && _sites[i].vx > 0.0f))
      _sites[i].vx = -_sites[i].vx;
    if((fy < _radius && _sites[i].vy < 0.0f)||
       (fy > h - _radius && _sites[i].vy > 0.0f))
      _sites[i].vy = -_sites[i].vy;
    _sites[i].x += _sites[i].vx * dt;
    _sites[i].y += _sites[i].vy * dt;
  }
}

void vd2Data(void) {
  GLfloat * data = calloc(2 * 4 * _nb_sites, sizeof *data);
  assert(data);
  for(int i = 0; i < _nb_sites; ++i) {
    /* texel 1 */
    data[8 * i + 0] = _sites[i].x;
    data[8 * i + 1] = _sites[i].y;
    /* texel 2 */
    data[8 * i + 4] = _sites[i].r;
    data[8 * i + 5] = _sites[i].g;
    data[8 * i + 6] = _sites[i].b;    
  }
  /* activer la texture _texId */
  glBindTexture(GL_TEXTURE_1D, _texId);
  /* transférer depuis CPU à GPU */  
  glTexImage1D(GL_TEXTURE_1D, 0, GL_RGBA, 2 * _nb_sites, 0, GL_RGBA, GL_FLOAT, data);
  free(data);
}


